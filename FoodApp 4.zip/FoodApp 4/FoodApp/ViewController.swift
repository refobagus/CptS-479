//
//  ViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 1/21/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit
//class Food{
//    var FoodName: String
//    var FoodNum: Int
//    var FoodPic: String
//    init(FoodName: String, FoodNum: Int, FoodPic: String) {
//        self.FoodName = FoodName;
//        self.FoodNum = FoodNum;
//        self.FoodPic = FoodPic;
//    }
//}
class ViewController: UIViewController {
    @IBOutlet weak var foodNum: UILabel!
    
    @IBOutlet weak var foodPic: UIImageView!
    
    @IBOutlet weak var foodName: UILabel!
    
    @IBOutlet weak var NextBtn: UIButton!
    var numPresses = 1
    var foodNameArr = ["Steak", "Ice Cream", "Corn Dog"]
    var foodPicArr = ["steak.jpeg", "icecream.jpeg","corndog.jpeg"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        foodPic.image = UIImage(named: "steak.jpeg")
        foodName.text = "Steak"
        foodNum.text = "My #1 Favorite Food is..."
    }
    
    @IBAction func nextPg(_ sender: UIButton) {
        if numPresses>=foodNameArr.count{
            numPresses=0
        }
        foodPic.image = UIImage(named: foodPicArr[numPresses])
        foodName.text = foodNameArr[numPresses]
        foodNum.text = "My #\(numPresses+1) Favorite Food is..."
        numPresses+=1
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){        //segue.identifier: NewQuestion
        let addFoodNum = segue.destination as! AddFoodViewController;
        addFoodNum.numPresses = self.foodNameArr.count + 1;
    }
}

