//
//  MainTableViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 2/18/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class MainTableViewController: UITableViewController{
    var foodNameArr = ["Steak", "Ice Cream", "Corn Dog"]
    var foodPicArr = ["steak.jpeg", "icecream.jpeg","corndog.jpeg"]
    var calories = [123,456,789]
    var foodDefName = "Food"
    var foodItems: [FoodItem] = []
    @IBOutlet var favtable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        //self.favtable.delegate = self
        //self.favtable.dataSource = self
        tableView.rowHeight = 58
        //self.favtable.isHidden = false
        foodItems.append(FoodItem(foodName: foodNameArr[0], foodPic: foodPicArr[0], calories: calories[0], ID: UUID().uuidString))
        foodItems.append(FoodItem(foodName: foodNameArr[1], foodPic: foodPicArr[1], calories: calories[1], ID: UUID().uuidString))
        foodItems.append(FoodItem(foodName: foodNameArr[2], foodPic: foodPicArr[2], calories: calories[2], ID: UUID().uuidString))
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return foodItems.count
    }


    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "foodCell", for: indexPath) as! FoodCell
        
        let indexRow = indexPath.row
        cell.foodpic?.image = UIImage(named: self.foodItems[indexRow].foodPic)
        cell.foodname?.text = self.foodItems[indexRow].foodName
        cell.calories?.text = "\(self.foodItems[indexRow].calories) cals"
        
        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
    // Return false if you do not want the specified item to be editable.
    return true
    }
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    if editingStyle == .delete {
    // Delete the row from the data source first
        foodItems.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
    } }

    @IBAction func addBtnPress(_ sender: Any) {
        foodItems.append(FoodItem(foodName: foodDefName, foodPic: "food.jpeg", calories: 100, ID: UUID().uuidString))
        
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let center = UNUserNotificationCenter.current()
        let dialogMessage = UIAlertController(title: "Food Notification", message: "Do you want to schedule notification for \(foodItems[indexPath.row].foodName)", preferredStyle: .alert)
        let yes = UIAlertAction(title: "Yes", style: .default, handler: { (action) in
            center.getNotificationSettings(completionHandler: { (settings) in
            if settings.alertSetting == .enabled {
                print("notifications enabled")
                self.scheduleNotification2(rowNum: indexPath.row)
            }
            else {
                print("notifications disabled")

            } })
            
        })
        let no = UIAlertAction(title: "No", style: .default, handler: { (action) in
            
        })
        
        dialogMessage.addAction(yes)
        dialogMessage.addAction(no)
        
        self.present(dialogMessage, animated: true, completion:nil)
        
    }
    
    func scheduleNotification2(rowNum: Int) {
    let content = UNMutableNotificationContent()
    content.title = "Food Alert"
        content.body = "Time to eat \(foodItems[rowNum].foodName)"
        content.userInfo["message"] = foodItems[rowNum].ID
    // Configure trigger for 5 seconds from now
    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5.0,
    repeats: false)
    let request = UNNotificationRequest(identifier: "NowPlusFive",
                         content: content, trigger: trigger)
        // Schedule request
    let center = UNUserNotificationCenter.current()
        center.add(request, withCompletionHandler: { (error) in
    if let err = error { print(err.localizedDescription)
    } })
    }
    
    func handleNotification(_ response: UNNotificationResponse) {
    let message = response.notification.request.content.userInfo["message"]
    as! String
    print("received notification message: \(message)")
    }
    // Create request
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
