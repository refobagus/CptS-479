//
//  TableViewController.swift
//  FoodApp11
//
//  Created by Refo Yudhanto on 4/13/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit
import CoreData

class TableViewController: UITableViewController {
    
    var managedObjectContext: NSManagedObjectContext!
    var appDelegate: AppDelegate!
    @IBOutlet var favtable: UITableView!
    
    var fooditems: [NSManagedObject] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        favtable.rowHeight = 58
        self.appDelegate = UIApplication.shared.delegate as? AppDelegate
        self.managedObjectContext = appDelegate.persistentContainer.viewContext
        fooditems = getPlayers()
    }


    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return fooditems.count
    }
    
    @IBAction func addTapped(_ sender: Any){
        let foodNameArr = ["Steak", "Chicken", "Spaghetti", "Hamburger", "Bats"]
        let name: String = foodNameArr.randomElement()!
        let foodpic = name+".jpeg"
        let calories = Int32.random(in: 100...500)
        let food = addFood(name: name, picture: foodpic, calories: calories)
        fooditems.append(food)
        tableView.reloadData()
    }

    
    func addFood(name:String, picture:String, calories:Int32)-> NSManagedObject {
    let food = NSEntityDescription.insertNewObject(forEntityName:
    "FoodItem", into: self.managedObjectContext)
    food.setValue(name, forKey: "foodName")
    food.setValue(picture, forKey: "foodPic")
    food.setValue(calories, forKey: "calories")
    self.appDelegate.saveContext() // In AppDelegate.swift
    return food
    }
    func getPlayers() -> [NSManagedObject]{
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "FoodItem")
        var foods: [NSManagedObject]!
        
        do {
        foods = try self.managedObjectContext.fetch(fetchRequest) }
        catch {
        print("getPlayers error: \(error)")
            
        }
        return foods
        
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "foodCell", for: indexPath) as! FoodCell

        // Configure the cell...
        let row = indexPath.row
        let food = fooditems[row]
        cell.foodname?.text = food.value(forKey: "foodName") as? String
        let foodpic = food.value(forKey: "foodPic") as? String
        let calorie = food.value(forKey: "calories") as? Int32
        cell.foodpic?.image = UIImage(named: foodpic!)
        cell.calories?.text = "\(calorie!) cals"
        
        return cell
    }
    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    if editingStyle == .delete {
    // Delete the row from the data source first
        let row = indexPath.row
        let food = fooditems[row]
        fooditems.remove(at: row)
        removeFood(food)
        favtable.deleteRows(at: [indexPath], with: .fade)
    } }
    func removeFood(_ food:NSManagedObject) {
        managedObjectContext.delete(food)
        appDelegate.saveContext()
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
