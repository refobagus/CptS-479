//
//  ViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 1/21/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

