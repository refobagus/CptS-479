//
//  SmileGestureRecognizer.swift
//  Food App 8
//
//  Created by Refo Yudhanto on 3/11/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit
import UIKit.UIGestureRecognizerSubclass

class SmileGestureRecognizer: UIGestureRecognizer {
    var initialPoint: CGPoint!
    var previousPoint: CGPoint!
    var firsthalf: Bool!
    var secondhalf: Bool!
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
    print("smile: touchesBegan")
    let touch = touches.first
    if let point = touch?.location(in: self.view) {
        drawBox(point)
        initialPoint = point
        previousPoint = point
        state = .began
        firsthalf = true
        secondhalf = false
        clearBoxes()
    }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
    print("smile: touchesMoved")
    let touch = touches.first
    if let point = touch?.location(in: self.view) {
        drawBox(point)
        if (detectfirsthalf(previousPoint,point) && firsthalf==true) { previousPoint = point
            state = .changed
        }
        else if (detectsecondhalf(previousPoint,point)){
            previousPoint = point
            state = .changed
            firsthalf = false
            secondhalf = true
        }
        else {
            state = .failed
        }
        
        }
    }
    func detectfirsthalf(_ prev:CGPoint, _ curr:CGPoint)-> Bool{
        if(curr.x >= prev.x && curr.y>=prev.y){
            return true
        }
        return false
    }
    func detectsecondhalf(_ prev:CGPoint, _ curr:CGPoint)-> Bool{
        if(curr.x >= prev.x && curr.y<=prev.y){
            return true
        }
        return false
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
    print("smile: touchesEnded")
    let touch = touches.first
    if let point = touch?.location(in: self.view) {
        let d = distance(point, initialPoint)
        if d > 100.0 {
            state = .ended
            }
        else {
            state = .failed
            }
        
        }
    }
    func distance(_ point1:CGPoint, _ point2:CGPoint) -> Double{
        let xdiff = point1.x - point2.x
        let ydiff = point1.y - point2.y
        return Double(sqrt(xdiff*xdiff + ydiff*ydiff))
    }

        
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        print("smile: touchesCancelled")
        state = .cancelled }
        
    override func reset() {
        print("smile: reset")
        clearBoxes()
        }
        
        var boxViews: [UIView] = []


        func drawBox(_ point: CGPoint) {
        let boxRect = CGRect(x: point.x, y: point.y,
        width: 5.0, height: 5.0)
        let boxView = UIView(frame: boxRect)
            boxView.backgroundColor = UIColor.red
            self.view?.addSubview(boxView)
            boxViews.append(boxView)
        }
    
        func clearBoxes() {
           for boxView in boxViews {
            boxView.removeFromSuperview()
            }
        boxViews.removeAll()
        }
        
        
    }

