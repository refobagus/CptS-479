//
//  ViewController.swift
//  Food App 8
//
//  Created by Refo Yudhanto on 3/9/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {
    @IBOutlet weak var tasteImage: UIImageView!
    
    @IBOutlet weak var tasteLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        // In viewDidLoad...
        tasteImage.isHidden = true
        tasteLable.isHidden = true
        let smileGestureRecognizer = SmileGestureRecognizer(target: self,
        action: #selector(handleSmile))
        smileGestureRecognizer.delegate = self
        
        let frownGestureRecognizer = FrownGestureRecognizer(target: self,
        action: #selector(handleFrown))
        frownGestureRecognizer.delegate = self
        
        self.view.addGestureRecognizer(smileGestureRecognizer)
        self.view.addGestureRecognizer(frownGestureRecognizer)

        
    }
    @objc func handleSmile(_ sender: SmileGestureRecognizer) {
        if sender.state == .ended && sender.secondhalf == true && sender.firsthalf==false {
            print("smile detected")
            tasteLable.text = "Taste great!"
            tasteImage.image = UIImage(named: "yummy.png")
            sender.firsthalf = true
            sender.secondhalf = false
            tasteImage.isHidden = false
            tasteLable.isHidden = false
        }
        else{
            tasteImage.isHidden = true
            tasteLable.isHidden = true
        }
    }
    @objc func handleFrown(_ sender: FrownGestureRecognizer) {
        if sender.state == .ended && sender.secondhalf == true && sender.firsthalf==false {
            print("smile detected")
            tasteLable.text = "Taste bad!"
            tasteImage.image = UIImage(named: "yuck.png")
            sender.firsthalf = true
            sender.secondhalf = false
            tasteImage.isHidden = false
            tasteLable.isHidden = false
        }
        else{
            tasteImage.isHidden = true
            tasteLable.isHidden = true
        }
    }
    
    var boxViews: [UIView] = []


    func drawBox(_ point: CGPoint) {
    let boxRect = CGRect(x: point.x, y: point.y,
    width: 5.0, height: 5.0)
    let boxView = UIView(frame: boxRect)
        boxView.backgroundColor = UIColor.red
        self.view?.addSubview(boxView)
        boxViews.append(boxView)
    }
    func clearBoxes() {
       for boxView in boxViews {
        boxView.removeFromSuperview()
        }
    boxViews.removeAll()
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
            if gestureRecognizer is SmileGestureRecognizer {
                if otherGestureRecognizer is FrownGestureRecognizer {
                    return true
            }
                
        }
        return false
    }
    // In ViewController
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if touch.view is UIButton {
            return false
    }
    return true
    }
    @IBAction func clearbutton(_ sender: Any) {
        tasteImage.isHidden = true
        tasteLable.isHidden = true
    }
    
}

