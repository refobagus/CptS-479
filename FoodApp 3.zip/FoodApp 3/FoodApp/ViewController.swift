//
//  ViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 1/21/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var foodNum: UILabel!
    
    @IBOutlet weak var foodPic: UIImageView!
    
    @IBOutlet weak var foodName: UILabel!

    
    @IBOutlet weak var TimeSlider: UISlider!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    @IBOutlet weak var startBtn: UIButton!
    
    @IBOutlet weak var stopBtn: UIButton!
    
    var seconds = 5
    var timer = Timer()
    var numCounter = 1
    var foodNameArr = ["Steak", "Ice Cream", "Corn Dog"]
    var foodPicArr = ["steak.jpeg", "icecream.jpeg","corndog.jpeg"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        foodPic.image = UIImage(named: "steak.jpeg")
        foodName.text = "Steak"
        foodNum.text = "My #1 Favorite Food is..."
        startBtn.isEnabled = true
        stopBtn.isEnabled = false
        timeLabel.text = "Delay: 5s"
    }
    @IBAction func sliderMove(_ sender: UISlider) {
        seconds = Int(sender.value)
        timeLabel.text = "Delay: \(seconds)s"
    }
    
    @IBAction func buttonStart(_ sender: Any) {
        startBtn.isEnabled = false
        stopBtn.isEnabled = true
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(seconds)-1, target: self, selector: #selector(ViewController.updateTimer), userInfo: nil, repeats: true)
    }
    @IBAction func buttonStop(_ sender: Any) {
        startBtn.isEnabled = true
        stopBtn.isEnabled = false
        timer.invalidate()
        seconds=5
        TimeSlider.setValue(5, animated: true)
        timeLabel.text = "Delay: \(seconds)s"
    }
    func nextPg(numSlides: Int) {
        foodPic.image = UIImage(named: foodPicArr[numSlides])
        foodName.text = foodNameArr[numSlides]
        foodNum.text = "My #\(numSlides+1) Favorite Food is..."
    }
    @objc func updateTimer(){
        if(numCounter>=3){
            numCounter=0
        }
        nextPg(numSlides: numCounter)
        numCounter+=1
    }
}

