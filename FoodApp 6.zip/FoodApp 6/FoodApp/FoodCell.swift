//
//  FoodCell.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 2/18/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class FoodCell: UITableViewCell {

    @IBOutlet weak var foodname: UILabel!
    @IBOutlet weak var calories: UILabel!
    @IBOutlet weak var foodpic: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
