//
//  AddFoodViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 2/11/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit

class AddFoodViewController: UIViewController {
    @IBOutlet weak var promptText: UILabel!
    var numPresses : Int = 1;
    @IBOutlet weak var FoodInput: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        promptText.text = "Enter food name #\(numPresses)"
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard));
        tap.cancelsTouchesInView = false

        view.addGestureRecognizer(tap)
    }
    func fillAnswer() -> [String]{
        var food: [String] = []
        if self.FoodInput.text?.isEmpty != true {
            food.append(self.FoodInput.text!)
        }
        return food
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    @IBAction func Save(_ sender: Any) {
//        let Answer = fillAnswer();
////        let FoodData = self.navigationController?.viewControllers[0] as! ViewController;
//        FoodData.foodNameArr.append(Answer[0])
//        FoodData.foodPicArr.append("food.jpeg")
        self.navigationController?.popViewController(animated:true);
    }
    
  
}
