//
//  FoodItem.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 2/18/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import Foundation

class FoodItem{
    var foodName: String;
    var foodPic: String;
    var calories: Int;
    init(foodName: String, foodPic: String,
         calories: Int){
        self.foodName = foodName;
        self.foodPic = foodPic;
        self.calories = calories;
    }
}

