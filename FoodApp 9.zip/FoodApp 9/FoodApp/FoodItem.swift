//
//  FoodItem.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 2/18/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import Foundation

class FoodItem{
    var foodName: String;
    var foodPic: String;
    var calories: Int;
    var ID: String;
    init(foodName: String, foodPic: String,
         calories: Int, ID: String){
        self.foodName = foodName;
        self.foodPic = foodPic;
        self.calories = calories;
        self.ID = ID;
    }
}

