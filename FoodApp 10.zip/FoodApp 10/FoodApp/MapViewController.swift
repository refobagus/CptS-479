//
//  MapViewController.swift
//  FoodApp
//
//  Created by Refo Yudhanto on 3/24/20.
//  Copyright © 2020 Refo Yudhanto. All rights reserved.
//

import UIKit
import CoreLocation

class MapViewController: UIViewController{
    var foodname : String!;

    @IBOutlet weak var foodName: UILabel!
    var place: String = "<Undefined>";
    var UrlStr: String! = ""
    @IBOutlet weak var FoodPic: UIImageView!
    var baseUri: String = "https://spoonacular.com/recipeImages/";
    var apikey: String = "&apiKey=e236a49aa94a4b609a048161e7aa1b09"
    override func viewDidLoad() {
        super.viewDidLoad()
        let Url: String! =  "https://api.spoonacular.com/recipes/search?query="
        let tas: String! = Url + foodname
        self.UrlStr = tas + apikey
        getNews()
    }
    
   
    
    func getNews() {
    // May not know exactly what's in the URL, so replace special characters with % encoding
        if let urlStr = UrlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            if let url = URL(string: urlStr) {
                let dataTask = URLSession.shared.dataTask(with: url,completionHandler: handleNewsResponse)
                dataTask.resume()
            }
            
        }
    }
    
    func handleNewsResponse (data: Data?, response: URLResponse?, error: Error?) {
        // 1. Check for error in request (e.g., no network connection)
        self.baseUri = "https://spoonacular.com/recipeImages/"
        if let err = error {
            print("error: \(err.localizedDescription)")
            return
        }
        // 2.
        //Check for improperly-formatted response
        guard let httpResponse = response as? HTTPURLResponse else { print("error: improperly-formatted response")
            return
        }
        let statusCode = httpResponse.statusCode
        // 3.
        guard statusCode == 200 else {
            let msg = HTTPURLResponse.localizedString(forStatusCode: statusCode)
            print("HTTP \(statusCode) error: \(msg)")
            return
        }
        guard let somedata = data else {
            print("error: no data")
            return
        }
        guard let jsonObj = try? JSONSerialization.jsonObject(with: somedata),
            let jsonDict1 = jsonObj as? [String: Any],
            let articleArray = jsonDict1["results"] as? [Any], articleArray.count > 0,
            let jsonDict2 = articleArray[0] as? [String: Any],
            let titleStr = jsonDict2["title"] as? String,
            let imgurl = jsonDict2["imageUrls"] as? [String]
            else {
                self.foodName.text = "No recipe found"
                
                return
        }
        let urlToImage = imgurl[0]
    // 6. Everything seems okay
        baseUri.append(urlToImage)
        self.loadNewsImage(baseUri)
        DispatchQueue.main.async {
            self.foodName.text = titleStr
        }
    }
    
    func loadNewsImage(_ urlString: String) {
        if let urlStr = urlString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            if let url = URL(string: urlStr) {
                let dataTask = URLSession.shared.dataTask(with: url,completionHandler: {(data, response, error) -> Void in
                    if let imageData = data {
                        let image = UIImage(data: imageData)
                        DispatchQueue.main.async {
                            self.FoodPic.image = image
                        }
                    }
                })
                dataTask.resume()
            }
        }
    
    }
    
    // URL comes from API response; definitely needs some safety checks if let urlStr = urlString.addingP
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
